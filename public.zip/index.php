<?php
    /**
      * @author Ilori Stephen A
    **/
    require_once __DIR__ . '/vendor/autoload.php';
    require_once __DIR__ . '/App/routes/api.php';

?>
