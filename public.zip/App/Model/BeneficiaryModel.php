<?php
    namespace App;
    use App\Model;
    
    

    class BeneficiaryModel extends Model {


        public function ListOfbeneficiary($user_id, $user_state)
        {
           
             $StringData = Parent::SeperateToString($user_state);

            if($user_id=="admin"){
               $myQuery = "SELECT * FROM `ms_state`";
            }else{
                $myQuery = "SELECT * FROM `ms_state` WHERE  Fullname IN ($StringData)";
            }
           
            
            $Sql = $myQuery;
            Parent::query($Sql);

            $Data = Parent::fetchAll();
            if (!empty($Data)) {
                return array(
                    'status' => true,
                    'data' => $Data
                );
            }

            return array(
                'status' => false,
                'data' => []
            );
        }



    }
?>
